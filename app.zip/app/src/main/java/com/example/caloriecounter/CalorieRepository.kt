package com.example.caloriecounter

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Room
//import com.bignerdranch.android.criminalintent.database.CrimeDatabase
import java.util.*
import java.util.concurrent.Executors

private const val DATABASE_NAME = "calorie-database"

class CalorieRepository private constructor(context: Context) {

    private val database : CalorieDatabase = Room.databaseBuilder(
        context.applicationContext,
        CalorieDatabase::class.java,
        DATABASE_NAME
    ).build()
    private val calorieDao = database.calorieDao()
    private val executor = Executors.newSingleThreadExecutor()

    fun getCalorie(): LiveData<List<Calorie>> = calorieDao.getCalorie()

    fun getCalorie(id: UUID): LiveData<Calorie?> = calorieDao.getCalorie(id)

    fun updateCrime(calorie: Calorie) {
        executor.execute {
            calorieDao.updateCrime(calorie)
        }
    }

    fun addCalorie(calorie: Calorie) {
        executor.execute {
            calorieDao.addCrime(calorie)
        }
    }

    companion object {
        private var INSTANCE: CalorieRepository? = null

        fun initialize(context: Context) {
            if (INSTANCE == null) {
                INSTANCE = CalorieRepository(context)
            }
        }

        fun get(): CalorieRepository {
            return INSTANCE ?:
            throw IllegalStateException("CalorieRepository must be initialized")
        }
    }
}