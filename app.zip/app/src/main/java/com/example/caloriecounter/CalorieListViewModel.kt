package com.example.caloriecounter

import androidx.lifecycle.ViewModel

class CalorieListViewModel : ViewModel() {

    private val calorieRepository = CalorieRepository.get()
    val calorieListLiveData = calorieRepository.getCalorie()

    fun addCrime(calorie: Calorie) {
        calorieRepository.addCrime(calorie)
    }
}