package com.example.caloriecounter.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
//import com.bignerdranch.android.criminalintent.Crime
import java.util.*

@Dao
interface CalorieDao {

    @Query("SELECT * FROM calorie")
    fun getCrimes(): LiveData<List<Calorie>>

    @Query("SELECT * FROM crime WHERE id=(:id)")
    fun getCalorie(id: UUID): LiveData<Calorie?>

    @Update
    fun updateCalorie(crime: Calorie)

    @Insert
    fun addCalorie(crime: Calorie)
}